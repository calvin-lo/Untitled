#!/bin/bash
pkill -9 output
pkill -9 main.sh