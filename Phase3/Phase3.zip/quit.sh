#!/bin/bash
sleep 0.1
pkill -2 output 